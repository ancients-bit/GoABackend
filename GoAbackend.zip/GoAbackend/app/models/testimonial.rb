class Testimonial < ApplicationRecord
  # Add validations and associations here
end
