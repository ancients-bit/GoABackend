# 🌿 Garden of Ancients Backend (GOABACKEND)

GOABACKEND is the admin and API backend for [Garden of Ancients], Kenya’s premier environmental learning space.  
Built with Ruby on Rails, it powers the booking, blogging, testimonials, and newsletter features of the main Garden of Ancients website.

---

## 🛠️ Features

- **Admin Dashboard:** Manage bookings, blogs, testimonials, newsletter subscribers, and view quick stats and notifications.
- **API:** Provides endpoints for the Next.js frontend to submit and fetch bookings, testimonials, blogs, and newsletter subscriptions.
- **Authentication:** Secured with Devise for admin users.
- **Background Jobs:** Newsletter sending and notifications are handled via Sidekiq.
- **File Uploads:** Blog post images and other media supported via ActiveStorage.

---

## 🚀 Getting Started

### Prerequisites

- Ruby 3.1 or higher
- Rails 7.1 or higher
- Bundler
- SQLite3 (default for local development)
- Node.js & Yarn (for JS/Asset pipeline if needed)
- Redis (for Sidekiq background jobs)

### Setup

1. **Clone the repository**
    ```bash
    git clone 
    cd GOABACKEND
    ```

2. **Install dependencies**
    ```bash
    bundle install
    ```

3. **Set up the database**
    ```bash
    rails db:create db:migrate
    ```

4. **Start Redis (for Sidekiq background jobs)**
    - On Mac/Linux:
      ```bash
      redis-server
      ```
    - On Windows, use Redis Desktop Manager or install as a Windows service.

5. **Start the Rails server**
    ```bash
    rails server
    ```

## � File Structure

```text
GoAbackend/
├── app/
│   ├── assets/
│   │   ├── images/                  # Place for image assets
│   │   ├── javascripts/             # (Legacy) JavaScript files
│   │   └── stylesheets/             # CSS/SCSS stylesheets for the app and admin
│   │       ├── application.css      # Main app CSS
│   │       ├── active_admin.scss    # Main ActiveAdmin CSS/SCSS manifest
│   │       ├── active_admin_custom.css # Custom styles for ActiveAdmin
│   │       └── admin_login.css      # Custom styles for the admin login page
│   ├── controllers/                 # Rails controllers (handle web requests)
│   │   ├── admin/                   # Admin namespace controllers (ActiveAdmin customizations)
│   │   │   ├── blog_posts_controller.rb
│   │   │   ├── bookings_controller.rb
│   │   │   ├── dashboard_controller.rb
│   │   │   └── sessions_controller.rb
│   │   ├── application_controller.rb # Base controller for all controllers
│   │   ├── base_controller.rb        # (Custom) Shared logic for controllers
│   │   ├── blog_posts_controller.rb  # Public blog posts controller
│   │   ├── bookings_controller.rb    # Public bookings controller
│   │   ├── dashboard_controller.rb   # Public dashboard controller
│   │   ├── subscribers_controller.rb # Public newsletter subscribers controller
│   │   └── testimonials_controller.rb# Public testimonials controller
│   ├── jobs/                        # Background jobs (ActiveJob)
│   │   ├── application_job.rb
│   │   └── newsletter_job.rb
│   ├── mailers/                     # Mailers for sending emails
│   │   ├── application_mailer.rb
│   │   ├── booking_mailer.rb
│   │   ├── newsletter_mailer.rb
│   │   └── notification_mailer.rb
│   ├── models/                      # Database models (ActiveRecord)
│   │   ├── admin_user.rb            # Devise/ActiveAdmin admin user model
│   │   ├── application_record.rb    # Base model for all models
│   │   ├── blog_post.rb             # Blog post model
│   │   ├── booking.rb               # Booking model
│   │   ├── subscriber.rb            # Newsletter subscriber model
│   │   └── testimonial.rb           # Testimonial model
│   └── views/                       # View templates (HTML/ERB)
│       ├── layouts/
│       │   ├── active_admin.html.erb # Custom layout for ActiveAdmin (sidebar, etc.)
│       │   ├── mailer.html.erb
│       │   └── mailer.text.erb
│       └── active_admin/
│           └── devise/
│               └── sessions/
│                   └── new.html.erb # Custom admin login page
├── config/
│   ├── application.rb               # Main Rails config
│   ├── boot.rb                      # Boot file
│   ├── database.yml                 # Database configuration
│   ├── environment.rb               # Rails environment setup
│   ├── initializers/                # Rails and gem initializers
│   │   ├── active_admin.rb          # ActiveAdmin configuration
│   │   ├── devise.rb                # Devise configuration
│   │   └── ...                      # Other initializers
│   ├── locales/                     # i18n translation files
│   ├── routes.rb                    # Application routes
│   └── ...                          # Other config files
├── db/
│   ├── migrate/                     # Database migration files
│   ├── schema.rb                    # Current database schema
│   └── seeds.rb                     # Seed data for the database
├── public/                          # Publicly served static files (favicon, error pages, etc.)
│   ├── favicon.png                  # Your custom favicon
│   ├── icon.png, icon.svg           # Other icons
│   └── 404.html, 500.html, etc.     # Error pages
├── test/                            # Rails test files (if using Minitest)
│   └── ...                          # Test helpers, models, controllers, etc.
├── Gemfile                          # Gem dependencies
├── Gemfile.lock                     # Locked gem versions
├── README.md                        # Project documentation
└── ...                              # Other files (Dockerfile, scripts, etc.)
```

7. **Access the Admin Dashboard**
    - Visit [http://localhost:3000/admin](http://localhost:3000/admin)
    - Log in with the admin credentials (see below).

---

## 🧑‍💻 Creating Your First Admin User

After migration, open the Rails console:
```bash
rails console
