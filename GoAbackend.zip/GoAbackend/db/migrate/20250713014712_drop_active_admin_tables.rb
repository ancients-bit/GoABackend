class DropActiveAdminTables < ActiveRecord::Migration[8.0]
  def change
  end
end
